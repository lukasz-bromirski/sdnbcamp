'''
Created on Apr 16, 2014

@author: dli
'''
from translator.state_type import Type

"""
For certain types of entries in the configuration parameter, the key
may not corresponding to our internal key.
Example:
    (Type.ENCAP, '', '3')
we look up the internal key for it here.
"""

type2key = {Type.DEV:      'DeviceModel',
            Type.GRP:      'SharedConfig',
            Type.CONN:     'CONN',
            Type.ENCAP:    'VLAN',
            Type.ENCAPASS: 'ENCAPASS',
            Type.ENCAPREL: 'ENCAPREL',
            Type.VIF:      'VIF' }
