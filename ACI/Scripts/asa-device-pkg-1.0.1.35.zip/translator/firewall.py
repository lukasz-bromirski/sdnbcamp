'''
Created on Oct 17, 2013
Copyright (c) 2013 by Cisco Systems

@author: dli
'''
from base.dmobject import DMObject
from connector import ExIntfConfigRelFolder, InIntfConfigRelFolder, Connectors, Connector
from connector import InIPv6EnforceEUI64, ExIPv6EnforceEUI64
from bridge_group_interface import BridgeGroupIntfs
from static_route import IntStaticRoute, ExtStaticRoute
from rule.access_rule import AccessGroupList
from rule.nat_rule import NATRuleList, NATRuleDeployment
from service_policy import ExtConnectorServicePolicyContainer, IntConnectorServicePolicyContainer
from state_type import State, Type

class Firewall(DMObject):
    '''
    This is the function configuration of ASA, assuming the name of "MFunc" element in the device_specifcation is "Firewall".
    Add firewall related configuration objects by call self.register_child(dmobj) in
    the constructor as it is done in DeviceModel.__init(self)__.
    '''
    def __init__(self):
        DMObject.__init__(self, Firewall.__name__)
        self.register_child(ExIntfConfigRelFolder())
        self.register_child(InIntfConfigRelFolder())
        self.register_child(Connectors('CONN', Connector))
        self.register_child(BridgeGroupIntfs())
        self.register_child(NATRuleList())
        self.register_child(NATRuleDeployment()) # Must follow NATRuleList
        self.register_child(AccessGroupList('ExtAccessGroup', 'external'))
        self.register_child(AccessGroupList('IntAccessGroup', 'internal'))
        self.register_child(IntStaticRoute())
        self.register_child(ExtStaticRoute())
        self.register_child(InIPv6EnforceEUI64())
        self.register_child(ExIPv6EnforceEUI64())
        self.register_child(IntConnectorServicePolicyContainer())
        self.register_child(ExtConnectorServicePolicyContainer())
        self.cli2dmobject = self.build_cli2dmobject()

    def build_cli2dmobject(self):
        'Return a dictionary of CLI prefix to the DMObject that can translate that CLI'
        result = {}
        for child in self.children.values():
            cli_prefixes = child.get_cli_prefixes()
            for cli_prefix in cli_prefixes:
                if result.has_key(cli_prefix):
                    result[cli_prefix].append(child)
                else:
                    result[cli_prefix] = [child]
        return result

    def get_translator(self, cli):
        'Override the default to fast-track the lookup'
        cli_prefix = cli.split()[0] if isinstance(cli, basestring) else cli.command.split()[0]
        dmobjects = self.cli2dmobject.get(cli_prefix, None)
        if not dmobjects:
            return None
        for dmobj in dmobjects:
            #look into its children
            result = dmobj.get_translator(cli)
            if result:
                return result

    def get_connector(self, connector_name):
        for conn in self.get_child('CONN').children.itervalues():
            if 'conn_type' in conn.__dict__ and conn.conn_type == connector_name:
                return conn

    def create_missing_ifc_delta_cfg(self):
        '''Override the default to take care of the way self.delta_ifc_key is created
        '''
        if  not self.has_ifc_delta_cfg():
            '@todo isolate changes to key creation'
            self.delta_ifc_key = Type.FUNC, Firewall.__name__, self.ifc_key,
            self.delta_ifc_cfg_value = {'state': State.NOCHANGE, 'value': {}}
            ancestor = self.get_ifc_delta_cfg_ancestor()
            if ancestor:
                ancestor.delta_ifc_cfg_value['value'][self.delta_ifc_key] =  self.delta_ifc_cfg_value
        for child in self.children.values():
            child.create_missing_ifc_delta_cfg()
