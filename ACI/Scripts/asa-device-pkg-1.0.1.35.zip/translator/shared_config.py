'''
Created on Apr 21, 2014

@author: jeffryp

Copyright (c) 2013 by Cisco Systems, Inc.
All rights reserved.
'''

from base.dmlist import DMList
from base.dmobject import DMObject
from connector import Connectors
from firewall import Firewall
from state_type import State, Type

class SharedConfigs(DMList):
    'Container for the group SharedConfig translator, one per graph'

    def __init__(self):
        DMList.__init__(self, SharedConfig.__name__, SharedConfig)
        self.cli_prefixes = Firewall().get_cli_prefixes()

    def get_cli_prefixes(self):
        return self.cli_prefixes

    def get_firewall(self, group_instance):
        group = self.get_child(group_instance)
        if group:
            return group.get_child('Firewall')

    def get_translator(self, cli):
        if not self.is_my_cli(cli):
            return False
        # Create group instance based on Connector interface CLI during audit
        instance = Connectors.get_connector_group_instance(cli, self.get_top().is_virtual())
        if instance and instance not in self.children:
            group = SharedConfig(instance)
            self.register_child(group)
            group.create_missing_ifc_delta_cfg()

        for child in self.children.itervalues():
            if hasattr(self, 'get_translator'):
                result = child.get_translator(cli)
                if result:
                    return result

    def is_my_cli(self, cli):
        'filter out'
        if isinstance(cli, basestring):
            cli_prefix = cli.split()[0]
        else:
            cli_prefix = cli.command.split()[0]
        return cli_prefix in self.cli_prefixes

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        # Generate same-security-traffic command if needed
        for group in self.children.itervalues():
            fw = group.get_child('Firewall')
            conn_in = fw.get_connector('internal')
            conn_out = fw.get_connector('external')
            if ((conn_in and conn_in.state == State.CREATE) or
                    (conn_out and conn_out.state == State.CREATE)):
                self.generate_cli(asa_cfg_list, 'same-security-traffic permit inter-interface')
                break;

        DMList.ifc2asa(self, no_asa_cfg_stack, asa_cfg_list)

class SharedConfig(DMObject):
    '''
    This is the group configuration of the ASA, assuming the name of "MGrpCfg"
    element in the device_specifcation is "GroupConfig".

    Add group configuration objects by calling self.register_child(dmobj) in
    the constructor as it is done in DeviceModel.__init(self)__.
    '''

    def __init__(self, instance):
        DMObject.__init__(self, str(instance)) # Normalize instance to a string
        self.register_child(Firewall())

    def create_missing_ifc_delta_cfg(self):
        'Override the default to take care of the way self.delta_ifc_key is created'

        if  not self.has_ifc_delta_cfg():
            '@todo isolate changes to key creation'
            self.delta_ifc_key = Type.GRP, SharedConfig.__name__, self.ifc_key,
            self.delta_ifc_cfg_value = {'state': State.NOCHANGE, 'value': {}}
            ancestor = self.get_ifc_delta_cfg_ancestor()
            if ancestor:
                ancestor.delta_ifc_cfg_value['value'][self.delta_ifc_key] =  self.delta_ifc_cfg_value

        for child in self.children.values():
            child.create_missing_ifc_delta_cfg()

    def get_group_instance(self):
        if self.has_ifc_delta_cfg():
            return str(self.delta_ifc_key[2]) # Normalize instance to a string
