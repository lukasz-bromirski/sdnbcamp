'''
Created on June 5, 2014

@author: emilymw
Copyright (c) 2014 by Cisco Systems
'''
import translator
from base.simpletype import SimpleType
from base.dmobject import DMObject
from base.dmlist import DMList
from base.compositetype import CompositeType
from translator.state_type import State, Type
from translator.base.dmboolean import DMBoolean
import asaio.cli_interaction as cli_interaction
from translator.structured_cli import StructuredCommand
import utils.util as util

class LACPMaxBundles(DMList):
    'Container of LACPMaxBundle'
    def __init__(self):
        DMList.__init__(self, name='LACPMaxBundle', asa_key='interface Port-channel', child_class=LACPMaxBundle)

    def is_my_cli(self, cli):
        if not isinstance(cli, StructuredCommand):
            return False
        if not cli.command.startswith('interface Port-channel'):
            return False
        
        lacp_cli = filter(lambda cmd: cmd.startswith('lacp max-bundle'), cli.sub_commands)
        if len(lacp_cli) == 0:
            return False
        return True

class LACPMaxBundle(DMObject):
    'Model for "interface BVI" CLI'
    def __init__(self, name):
        DMObject.__init__(self, name,);
        self.register_child(PCID())
        self.register_child(LACPMax('lacp_max_bundle'))
        self.response_parser = cli_interaction.ignore_info_response_parser

    def set_action(self, state):
        self.delta_ifc_cfg_value['state'] = state

    def get_lacp_cli(self):
        child = self.get_child('lacp_max_bundle')
        return child.get_lacp_max_bundle_cli()

    def is_my_cli(self, cli):
        '''
        Must have the same interface mode command
        '''
        intf = self.get_child('interface')
        if intf:
            return intf.get_interface_cli() == cli.command
        return False

    def get_translator(self, cli):
        if self.is_my_cli(cli):
            return self
        return None

    def diff_ifc_asa(self, cli):
        'Diff the lacp max-bundle or create LACPMaxBundle'
        if not self.has_ifc_delta_cfg():
            lacp_cli = filter(lambda cmd: cmd.startswith('lacp max-bundle'), cli.sub_commands)
            lacp_max = lacp_cli[0].split(' ')[1]

            self.delta_ifc_key = (Type.FOLDER, 'LACPMaxBundle', 'pc' + lacp_max + '_' + cli.command)
            self.delta_ifc_cfg_value = {'state': State.DESTROY, 'value': {}}
            ancestor = self.get_ancestor_by_class(translator.devicemodel.DeviceModel)
            if not self.delta_ifc_key in ancestor.delta_ifc_cfg_value['value']:
                ancestor.delta_ifc_cfg_value['value'][self.delta_ifc_key] =  self.delta_ifc_cfg_value

            for child in self.children.values():
                child.diff_ifc_asa(cli)

            return
        if self.is_the_same_cli(cli):
            self.set_action(State.NOCHANGE)
        else:
            self.set_action(State.MODIFY)

    def is_the_same_cli(self, cli):
        '@return if the given CLI is the same as the one represented by me'
        return self.get_lacp_cli() == \
            filter(lambda cmd: cmd.startswith('lacp max-bundle'), cli.sub_commands)[0]

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        if not self.has_ifc_delta_cfg():
            return

        if self.delta_ifc_cfg_value['state'] == State.NOCHANGE:
            return

        pc_id = self.get_child('pc_id')
        lacp_max = self.get_child('lacp_max_bundle')
        self.mode_command = 'interface Port-channel' + pc_id.delta_ifc_cfg_value['value']

        if lacp_max.state == State.DESTROY:
            self.generate_cli(no_asa_cfg_stack, lacp_max.get_lacp_max_bundle_cli())
        elif lacp_max.state in [State.CREATE, State.MODIFY] :
            self.response_parser = cli_interaction.ignore_info_response_parser
            if self.delta_ifc_cfg_value['state'] == State.CREATE:
                self.generate_cli(asa_cfg_list, "no shutdown")
            self.generate_cli(asa_cfg_list, lacp_max.get_lacp_max_bundle_cli())

class LACPMax(DMObject):
    'Model after  "lacp max-bundle <1-16>'
    def __init__(self, instance):
        DMObject.__init__(self, ifc_key = instance, asa_key = 'lacp max-bundle')

    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        self.state = delta_ifc_cfg_value['state']

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        'Handled by LACPMaxBundle'
        pass

    def diff_ifc_asa(self, cli):
        'Compare cli and update action state'
        lacp_cli = filter(lambda cmd: cmd.startswith('lacp max-bundle'), cli.sub_commands)
        lacp_max = lacp_cli[0].split(' ')[2]

        if not self.has_ifc_delta_cfg():
            self.delta_ifc_key = (Type.PARAM, 'lacp_max_bundle', cli.command + '_' + lacp_max)
            self.delta_ifc_cfg_value = {'state': State.DESTROY, 'value':lacp_max}
            ancestor = self.get_ifc_delta_cfg_ancestor()
            ancestor.delta_ifc_cfg_value['value'][self.delta_ifc_key] =  self.delta_ifc_cfg_value
            return
        if lacp_cli == self.get_lacp_max_bundle_cli():
            self.delta_ifc_cfg_value['state'] = State.NOCHANGE
        else:
            self.delta_ifc_cfg_value['state'] = State.MODIFY

    def get_lacp_max_bundle_cli(self):
        'Return cli of a lacp max-bundle'
        cli = 'lacp max-bundle %s' % self.delta_ifc_cfg_value['value']
        if self.state == State.DESTROY:
            return 'no ' + cli
        return cli

class PCID(DMObject):
    'PCID class modeli'
    def __init__(self):
        DMObject.__init__(self, ifc_key = 'pc_id')

    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        self.state = delta_ifc_cfg_value['state']

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        pass

    def diff_ifc_asa(self, cli):
        'Compare cli and update action state'
        channel_id = cli.command.split('interface Port-channel')[1]

        if not self.has_ifc_delta_cfg():
            self.delta_ifc_key = (Type.PARAM, 'pc_id', cli.command + '_' + channel_id)
            self.delta_ifc_cfg_value = {'state': State.DESTROY, 'value':channel_id}
            ancestor = self.get_ifc_delta_cfg_ancestor()
            ancestor.delta_ifc_cfg_value['value'][self.delta_ifc_key] =  self.delta_ifc_cfg_value
            return
        if cli.command == self.get_channel_group_cli():
            self.delta_ifc_cfg_value['state'] = State.NOCHANGE
        else:
            self.delta_ifc_cfg_value['state'] = State.MODIFY

    def get_channel_group_cli(self):
        'Return cli of a channel-group'
        cli = 'channel-group %s mode active' % self.delta_ifc_cfg_value['value']
        if self.state == State.DESTROY:
            return 'no ' + cli
        return cli